Junior 加工包 · v1
模型、图纸与清单来自同一个版本。model/design.json 为可重新导入的模型数据。
图纸以标注尺寸为准。material-plan.csv 为整板排板估算：矩形毛坯、3 mm 锯缝、10 mm 切边，不是最优排版；purchase.csv 为逐件毛坯。
预算见 budget.csv：未填单价的项目不计金额，不编造价格。
检查范围见 package.json 的 coverage；承载、稳定性及实际工艺需要实物核实。
